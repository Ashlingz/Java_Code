
/**
 *
 * @author TUF
 */
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.*;
import java.util.Scanner;

//public class Server {
//    public static void main(String args[]) throws IOException
//    {
//        ServerSocket ss = new ServerSocket(8888);
//        System.out.println("Server is running and waiting for connection...");
//        
//        Socket s = ss.accept();
//        
//        System.out.println("A clinet has been connected to server...");
//        Scanner in = new Scanner(new InputStreamReader(s.getInputStream()));
//        PrintStream out = new PrintStream(s.getOutputStream());
//        
//        System.out.println("Waiting for client message..");
//        String msg = in.nextLine();
//        
//        out.print("Hello I recived your message");
//        out.flush();
//        
//        
//    }
//}

